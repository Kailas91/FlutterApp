
import 'dart:convert';

import 'package:get/get.dart';
import 'package:http/http.dart' as http;
class ProductListController extends GetxController{
  var userList = <Data>[].obs;
  var isLoading = true.obs;
   RxList favIcon = [].obs;
  

  @override
  void onInit() {
    super.onInit();
    getUsers();
  }

  Future<void> getUsers() async {
    try{
    const String userUrl = "http://fakestoreapi.com/products";
    final response = await http.get(Uri.parse(userUrl));
    if (response.statusCode == 200) {
      final List result = jsonDecode(response.body);
      userList.value = result.map((e) => Data.fromJson(e)).toList();
      favIcon.value = List.filled(userList.length+1, false);
      isLoading.value = false;
      update();
    } else {
      Get.snackbar('Error Loading data!',
          'Sever responded: ${response.statusCode}:${response.reasonPhrase.toString()}');
    }

  }
  on Exception{
   Get.snackbar('Error Loading data!',"");
   
  }
  }

changeFav(int index){
  favIcon[index]=!favIcon[index];
  print(favIcon);
  update();
}

}

class Data {
  int? id;
  String? title;
  double? price;
  String? description;
  String? image;


  Data({this.id, this.title, this.price, this.description, this.image});

  Data.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    title = json['title'];
    price =  double.parse(json['price'].toString());
    description = json['description'];
    image = json['image'];
    
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['title'] = this.title;
    data['price'] = this.price;
    data['description'] = this.description;
    data['image'] = this.image;

    return data;
  }
}