import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
class RegistrationController extends GetxController{
  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  late List<Map> registeredUser =[{}].obs;
  List registeredUname = [].obs;
  RxString loggedInUser = "".obs;
  var  matched = false.obs;
registerUser() async {

if(!registeredUname.contains(emailController.text)){
  registeredUser.addAll([{'name':nameController.text,'email':emailController.text,'password':passwordController.text}]);
  Get.snackbar('Register Success!!!!!!',"");
  registeredUname.add(emailController.text);
  print(registeredUser);
  nameController.clear();
  emailController.clear();
  passwordController.clear();
  }else 
  {
    Get.snackbar('Already Register User !!!!!!',"");
  }
  
  
}

changeMatched(bool val){
  matched.value = val;
  update();
}

}