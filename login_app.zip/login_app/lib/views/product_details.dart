// ignore_for_file: must_be_immutable

import 'package:flutter/material.dart';
import 'package:login_app/controller/product_list_controller.dart';
import 'package:get/get.dart';
class ProductDetails extends StatelessWidget {
  int index = 0;
   ProductDetails( this.index, {super.key});


  ProductListController productListController =
      Get.find<ProductListController>();

  @override
  Widget build(BuildContext context) {

      final controller = Get.find<ProductListController>();
    // final controller =  Get.put<UserController>(UserController());
    List<Data> userList = controller.userList;
    var size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(title: Text('Detail Product'),actions: <Widget>[IconButton(
          icon: Icon(
            Icons.logout,
            color: Colors.black,
          ),
          onPressed: () {
            Get.close(2);

            // do something
          },
        )],),
      
      body: Container(
        
        child: SizedBox(
            width: size.width,
            height: size.height,
            child: Obx(
        () => productListController.isLoading.value
            ? Center(
                child: CircularProgressIndicator(),
              )
            : Card(
                       elevation: 4.0,
                       
                       color: Colors.white,
                       child: Column(
                         children: [
                          ListTile(
                             title: Text(userList[index].title??'no name',style: TextStyle(fontSize: 12, color: Colors.blue),),
                             subtitle: Text(userList[index].description.toString(),style: TextStyle(fontSize: 10),),
                             //trailing: Icon(Icons.favorite_outline),
                           ),
                          Stack(
                  children: <Widget>[
                    Container(
                        decoration: const BoxDecoration(color: Colors.white,borderRadius: BorderRadius.all(Radius.circular(10))),
                        
                        alignment: Alignment.center,
                        //height: 80,
                        child: AspectRatio(
                          aspectRatio: 4/5,
                          child: Image.network(userList[index].image!,fit: BoxFit.fill))
                    ),
                    Align(
                      alignment: Alignment.bottomRight,
                      child: InkWell(
                    onTap: () {
                      productListController.changeFav(index);
                      // handle button press
                    },
                    child: Container(
                      width: 30,
                      height: 30,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.white,
                      ),
                      child: Obx(
                       () => productListController.favIcon[index]==true?Icon(
                          Icons.favorite,
                          color: Colors.red
                        ):Icon(
                          Icons.favorite_outline,
                          
                        ),
                      ),
                    ),
                  ),
                      
                      
                    )
                  ],
                  ),
                        ListTile(
                          leading: Text('Price :',style: TextStyle(fontSize: 11),),
                             title: Text(userList[index].price.toString(),style: TextStyle(fontSize: 12,fontWeight: FontWeight.bold),),
                             //subtitle: Text(userList[index].description.toString(),style: TextStyle(fontSize: 8),),
                             //trailing: Icon(Icons.favorite_outline),
                           ),   
                 
                         ],
                       ))
                
              
          
          )),
      ));
  }
}