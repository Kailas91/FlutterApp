import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:login_app/controller/registration_controller.dart';
import 'package:login_app/views/product_list.dart';
import 'package:login_app/views/sign_up.dart';
import 'package:http/http.dart' as http;
class LoginScreen extends StatelessWidget {
  
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

 RegistrationController registerationController =
      Get.find<RegistrationController>();

   login()  {
     registerationController.changeMatched(false);
    for(int i=0;i<registerationController.registeredUser.length;i++){
      if(registerationController.registeredUser[i]['email']==emailController.text&&registerationController.registeredUser[i]['password']==passwordController.text){
        Get.to(ProductList());
        registerationController.loggedInUser.value = emailController.text;
        emailController.clear();
        passwordController.clear();
        registerationController.changeMatched(true);
      }
    }
    if(!registerationController.matched.value){
Get.snackbar('Error', 'Invalid User');
    }

  }

  
  @override
  Widget build(BuildContext context) {
   
    var size = MediaQuery.of(context).size;
    return Scaffold(
        backgroundColor: Colors.blueGrey[200],
        body: Form(
          key: _formKey,
          child: Stack(children: [
            SizedBox(
              width: size.width,
              height: size.height,
              child: Align(
                alignment: Alignment.center,
                child: Container(
                  width: size.width * 0.85,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 20, vertical: 30),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: SingleChildScrollView(
                    child: Center(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          // SizedBox(height: size.height * 0.08),
                           const Center(
                            child: Text(
                             'Login',
                              style: TextStyle(
                                fontSize: 30,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          SizedBox(height: size.height * 0.06),
                          TextFormField(
                            controller: emailController,
                            validator: (value) {
                              //return Validator.validateEmail(value ?? "");
                            },
                            decoration: InputDecoration(
                              hintText: "Email",
                              isDense: true,
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                              ),
                            ),
                          ),
                          SizedBox(height: size.height * 0.03),
                          TextFormField(
                            obscureText: true,
                            controller: passwordController,
                            validator: (value) {
                              //return Validator.validatePassword(value ?? "");
                            },
                            decoration: InputDecoration(
                             
                              hintText: "Password",
                              isDense: true,
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                              ),
                            ),
                          ),
                          SizedBox(height: size.height * 0.04),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Expanded(
                                child: ElevatedButton(
                                  onPressed: login,
                                  style: ElevatedButton.styleFrom(
                                      primary: Colors.indigo,
                                      shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(10)),
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 40, vertical: 15)),
                                  child: const Text(
                                    "Login",
                                    style: TextStyle(
                                      fontSize: 20,
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: size.height * 0.04),

                           InkWell(
                            child:  Center(child: Container(
                               decoration:  const BoxDecoration(
                    border: Border(
                    bottom: BorderSide(color: Colors.blue))
                 ),
                              child: const Text("Registration ",  style: TextStyle(
                                  fontSize: 20,
                                  color: Colors.blue,
                                  //decoration: TextDecoration.underline,
                                ),),
                            ),),
                            
                            onTap: () {Get.to(SignUp());
                            emailController.clear();
                            passwordController.clear();
                            },)


                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ]),
        ));
  }
}